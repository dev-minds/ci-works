package com.fmbah.calculus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculusApplicationTests {

	@Test
	void contextLoads() {
	}

}
